/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package common;

import javax.swing.JOptionPane;
import java.io.File;
/**
 *
 * @author kaaeyy
 */
//public class OpenPdf {
//    public static void openById(String id){
//        try{
//            if((new File("/Users/kaaeyy/Documents"+id+".pdf")).exists()){
//                Process p = Runtime 
//                        .getRuntime()
//                        .exec("rundll32 url.dll, FileProtocolHandler /Users/kaaeyy/Documents"+id+".pdf");
//                
//            }
//            else
//                JOptionPane.showMessageDialog(null, "File did not exists");   
//        }
//        catch(Exception e){
//            JOptionPane.showMessageDialog(null, e);
//        }
//    }
//}

public class OpenPdf {
    public static void openById(String id){
        try{
            // Gunakan user home directory yang dinamis
            String userHome = System.getProperty("user.home");
            String filePath = userHome + File.separator + "Documents" + File.separator + id + ".pdf";
            File pdfFile = new File(filePath);
            
            System.out.println("Checking file: " + filePath); // Debug log
            
            if(pdfFile.exists()){
                // Gunakan "open" command untuk Mac
                ProcessBuilder pb = new ProcessBuilder("open", filePath);
                Process p = pb.start();
                
                System.out.println("PDF opened successfully: " + filePath); // Debug log
            }
            else {
                JOptionPane.showMessageDialog(null, "File did not exist: " + filePath);   
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error opening PDF: " + e.getMessage());
            e.printStackTrace(); // Print stack trace untuk debugging
        }
    }
}
